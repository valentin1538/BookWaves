<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$database = "Biblio";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("La connexion à la base de données a échoué : " . $conn->connect_error);
}

// Vérifier si des données ont été envoyées via la méthode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données envoyées depuis le formulaire après les avoir nettoyées
    $idLivre = mysqli_real_escape_string($conn, $_POST['id']);
    $titre = mysqli_real_escape_string($conn, $_POST['titre']);
    $auteur = mysqli_real_escape_string($conn, $_POST['auteur']);
    $editeur = mysqli_real_escape_string($conn, $_POST['editeur']);
    $langue = mysqli_real_escape_string($conn, $_POST['langue']);

    // Requête SQL préparée pour mettre à jour les métadonnées du livre dans la base de données
    $sql = "UPDATE livre 
            SET nom = '$titre', infos = 'Auteur: $auteur, Editeur: $editeur, Langue: $langue' 
            WHERE id = $idLivre";

    // Exécution de la requête SQL
    if ($conn->query($sql) === TRUE) {
        echo "Métadonnées du livre mises à jour avec succès.";
    } else {
        echo "Erreur lors de la mise à jour des métadonnées du livre : " . $conn->error;
    }
}

$conn->close(); // Fermer la connexion à la base de données
?>