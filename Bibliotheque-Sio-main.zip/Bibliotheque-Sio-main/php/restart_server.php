<?php
// Redémarrage de WampServer
exec('path/to/wampserver/restart_command');
?>